﻿
namespace ProyectoDeCatedraPOOFinal
{
    partial class FrmMenuIngreso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenuIngreso));
            this.btnReptiles = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.btnMamiferos = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnPeces = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnArtropodos = new Bunifu.Framework.UI.BunifuTileButton();
            this.frmElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.mamiferosElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.reptilesElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pecesElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.artropodosElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.btnVolverMenu = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReptiles
            // 
            this.btnReptiles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnReptiles.color = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnReptiles.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnReptiles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReptiles.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.btnReptiles.ForeColor = System.Drawing.Color.White;
            this.btnReptiles.Image = ((System.Drawing.Image)(resources.GetObject("btnReptiles.Image")));
            this.btnReptiles.ImagePosition = 20;
            this.btnReptiles.ImageZoom = 70;
            this.btnReptiles.LabelPosition = 41;
            this.btnReptiles.LabelText = "Reptiles";
            this.btnReptiles.Location = new System.Drawing.Point(318, 83);
            this.btnReptiles.Margin = new System.Windows.Forms.Padding(40);
            this.btnReptiles.Name = "btnReptiles";
            this.btnReptiles.Size = new System.Drawing.Size(189, 193);
            this.btnReptiles.TabIndex = 5;
            this.btnReptiles.Click += new System.EventHandler(this.btnReptiles_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.btnMinimizar);
            this.bunifuGradientPanel1.Controls.Add(this.btnCerrar);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(229)))), ((int)(((byte)(100)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(238)))), ((int)(((byte)(96)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(234)))), ((int)(((byte)(98)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(247)))), ((int)(((byte)(91)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(566, 40);
            this.bunifuGradientPanel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ingreso de animales";
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(482, 5);
            this.btnMinimizar.Margin = new System.Windows.Forms.Padding(5);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(30, 30);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMinimizar.TabIndex = 3;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(522, 5);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 30);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnCerrar.TabIndex = 2;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnMamiferos
            // 
            this.btnMamiferos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnMamiferos.color = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnMamiferos.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnMamiferos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMamiferos.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.btnMamiferos.ForeColor = System.Drawing.Color.White;
            this.btnMamiferos.Image = ((System.Drawing.Image)(resources.GetObject("btnMamiferos.Image")));
            this.btnMamiferos.ImagePosition = 20;
            this.btnMamiferos.ImageZoom = 70;
            this.btnMamiferos.LabelPosition = 41;
            this.btnMamiferos.LabelText = "Mamíferos";
            this.btnMamiferos.Location = new System.Drawing.Point(49, 83);
            this.btnMamiferos.Margin = new System.Windows.Forms.Padding(40);
            this.btnMamiferos.Name = "btnMamiferos";
            this.btnMamiferos.Size = new System.Drawing.Size(189, 193);
            this.btnMamiferos.TabIndex = 3;
            this.btnMamiferos.Click += new System.EventHandler(this.btnMamiferos_Click);
            // 
            // btnPeces
            // 
            this.btnPeces.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnPeces.color = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnPeces.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnPeces.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPeces.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.btnPeces.ForeColor = System.Drawing.Color.White;
            this.btnPeces.Image = ((System.Drawing.Image)(resources.GetObject("btnPeces.Image")));
            this.btnPeces.ImagePosition = 20;
            this.btnPeces.ImageZoom = 70;
            this.btnPeces.LabelPosition = 41;
            this.btnPeces.LabelText = "Peces";
            this.btnPeces.Location = new System.Drawing.Point(49, 356);
            this.btnPeces.Margin = new System.Windows.Forms.Padding(40);
            this.btnPeces.Name = "btnPeces";
            this.btnPeces.Size = new System.Drawing.Size(189, 193);
            this.btnPeces.TabIndex = 6;
            this.btnPeces.Click += new System.EventHandler(this.btnPeces_Click);
            // 
            // btnArtropodos
            // 
            this.btnArtropodos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnArtropodos.color = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnArtropodos.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnArtropodos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnArtropodos.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.btnArtropodos.ForeColor = System.Drawing.Color.White;
            this.btnArtropodos.Image = ((System.Drawing.Image)(resources.GetObject("btnArtropodos.Image")));
            this.btnArtropodos.ImagePosition = 20;
            this.btnArtropodos.ImageZoom = 70;
            this.btnArtropodos.LabelPosition = 41;
            this.btnArtropodos.LabelText = "Artrópodos";
            this.btnArtropodos.Location = new System.Drawing.Point(318, 356);
            this.btnArtropodos.Margin = new System.Windows.Forms.Padding(40);
            this.btnArtropodos.Name = "btnArtropodos";
            this.btnArtropodos.Size = new System.Drawing.Size(189, 193);
            this.btnArtropodos.TabIndex = 7;
            this.btnArtropodos.Click += new System.EventHandler(this.btnArtropodos_Click);
            // 
            // frmElipse
            // 
            this.frmElipse.ElipseRadius = 20;
            this.frmElipse.TargetControl = this;
            // 
            // mamiferosElipse
            // 
            this.mamiferosElipse.ElipseRadius = 25;
            this.mamiferosElipse.TargetControl = this.btnMamiferos;
            // 
            // reptilesElipse
            // 
            this.reptilesElipse.ElipseRadius = 25;
            this.reptilesElipse.TargetControl = this.btnReptiles;
            // 
            // pecesElipse
            // 
            this.pecesElipse.ElipseRadius = 25;
            this.pecesElipse.TargetControl = this.btnPeces;
            // 
            // artropodosElipse
            // 
            this.artropodosElipse.ElipseRadius = 25;
            this.artropodosElipse.TargetControl = this.btnArtropodos;
            // 
            // btnVolverMenu
            // 
            this.btnVolverMenu.ActiveBorderThickness = 1;
            this.btnVolverMenu.ActiveCornerRadius = 20;
            this.btnVolverMenu.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnVolverMenu.ActiveForecolor = System.Drawing.Color.White;
            this.btnVolverMenu.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnVolverMenu.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolverMenu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVolverMenu.BackgroundImage")));
            this.btnVolverMenu.ButtonText = "Volver al menú";
            this.btnVolverMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolverMenu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverMenu.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnVolverMenu.IdleBorderThickness = 1;
            this.btnVolverMenu.IdleCornerRadius = 20;
            this.btnVolverMenu.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnVolverMenu.IdleForecolor = System.Drawing.Color.White;
            this.btnVolverMenu.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnVolverMenu.Location = new System.Drawing.Point(388, 594);
            this.btnVolverMenu.Margin = new System.Windows.Forms.Padding(5);
            this.btnVolverMenu.Name = "btnVolverMenu";
            this.btnVolverMenu.Size = new System.Drawing.Size(164, 41);
            this.btnVolverMenu.TabIndex = 9;
            this.btnVolverMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnVolverMenu.Click += new System.EventHandler(this.btnVolverMenu_Click);
            // 
            // FrmMenuIngreso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 642);
            this.Controls.Add(this.btnVolverMenu);
            this.Controls.Add(this.btnArtropodos);
            this.Controls.Add(this.btnPeces);
            this.Controls.Add(this.btnReptiles);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.btnMamiferos);
            this.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "FrmMenuIngreso";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMenuIngreso";
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuTileButton btnReptiles;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox btnMinimizar;
        private System.Windows.Forms.PictureBox btnCerrar;
        private Bunifu.Framework.UI.BunifuTileButton btnMamiferos;
        private Bunifu.Framework.UI.BunifuTileButton btnPeces;
        private Bunifu.Framework.UI.BunifuTileButton btnArtropodos;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuElipse frmElipse;
        private Bunifu.Framework.UI.BunifuElipse mamiferosElipse;
        private Bunifu.Framework.UI.BunifuElipse reptilesElipse;
        private Bunifu.Framework.UI.BunifuElipse pecesElipse;
        private Bunifu.Framework.UI.BunifuElipse artropodosElipse;
        private Bunifu.Framework.UI.BunifuThinButton2 btnVolverMenu;
    }
}