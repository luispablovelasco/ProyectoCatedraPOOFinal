﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoDeCatedraPOOFinal
{
    public partial class FrmMenuIngreso: Form
    {
        public FrmMenuIngreso()
        {
            InitializeComponent();
        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Hide();
        }

        private void btnMamiferos_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmMamifero frmMamifero = new FrmMamifero();
            frmMamifero.Show();
        }

        private void btnReptiles_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmReptil frmReptil = new FrmReptil();
            frmReptil.Show();
        }

        private void btnPeces_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmPez frmPez = new FrmPez();
            frmPez.Show();
        }

        private void btnArtropodos_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmAntropodo frmAntropodo = new FrmAntropodo();
            frmAntropodo.Show();
        }
    }
}
