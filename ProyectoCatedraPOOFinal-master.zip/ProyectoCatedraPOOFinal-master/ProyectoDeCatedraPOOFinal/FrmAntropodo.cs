﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProyectoDeCatedraPOOFinal
{
    public partial class FrmAntropodo : ProyectoDeCatedraPOOFinal.FrmIngreso
    {
        public FrmAntropodo()
        {
            InitializeComponent();
        }

        private void FrmAntropodo_Load(object sender, EventArgs e)
        {
            cbTipoApendices.Items.Clear();
            cbTipoApendices.Items.Add("Antenas");
            cbTipoApendices.Items.Add("Antenulas");
            cbTipoApendices.Items.Add("Gnatopidios");
            cbTipoApendices.Items.Add("Hileras");
            cbTipoApendices.Items.Add("Peines");
            cbTipoApendices.Items.Add("Labio");
            cbTipoApendices.Items.Add("Mandíbulas");
            cbTipoApendices.Items.Add("Maxilas");
            cbTipoApendices.Items.Add("Maxilípeods");
            cbTipoApendices.Items.Add("Masillas");
            cbTipoApendices.Items.Add("Ovejeros");
            cbTipoApendices.Items.Add("Patas");
            cbTipoApendices.Items.Add("Pedipalpos");
            cbTipoApendices.Items.Add("Periópodos");
            cbTipoApendices.Items.Add("Leopoldos");
            cbTipoApendices.Items.Add("Quelíceros");
            cbTipoApendices.Items.Add("Quilíferos");
            cbTipoApendices.Items.Add("Toracópodos");
            cbTipoApendices.Items.Add("Uro podios");
            cbTipoApendices.Items.Add("Abdómenes");

        }
    }
}
