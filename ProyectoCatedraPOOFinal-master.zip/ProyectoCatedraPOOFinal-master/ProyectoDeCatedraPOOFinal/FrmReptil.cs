﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProyectoDeCatedraPOOFinal
{
    public partial class FrmReptil : ProyectoDeCatedraPOOFinal.FrmIngreso
    {
        public FrmReptil()
        {
            InitializeComponent();
        }

        private void FrmReptil_Load(object sender, EventArgs e)
        {
            cbTipoResp.Items.Clear();
            cbTipoResp.Items.Add("Pulmonar");
            cbTipoResp.Items.Add("Cutanea");
        }
    }
}
