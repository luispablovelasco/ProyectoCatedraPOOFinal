﻿
namespace ProyectoDeCatedraPOOFinal
{
    partial class FrmIngreso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmIngreso));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.frmElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.txtNomComun = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomCientifico = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbClasificacion = new Guna.UI.WinForms.GunaComboBox();
            this.bunifuGroupBox1 = new Bunifu.UI.WinForms.BunifuGroupBox();
            this.bunifuGroupBox2 = new Bunifu.UI.WinForms.BunifuGroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAgregarFoto = new Bunifu.Framework.UI.BunifuThinButton2();
            this.lbNombreFoto = new System.Windows.Forms.Label();
            this.cbDescripcion = new Guna.UI.WinForms.GunaComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bunifuGroupBox3 = new Bunifu.UI.WinForms.BunifuGroupBox();
            this.btnVolverMenu = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnIngresar = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtID = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCargarFoto = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            this.bunifuGroupBox1.SuspendLayout();
            this.bunifuGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.btnMinimizar);
            this.bunifuGradientPanel1.Controls.Add(this.btnCerrar);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(229)))), ((int)(((byte)(100)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(238)))), ((int)(((byte)(96)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(234)))), ((int)(((byte)(98)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(247)))), ((int)(((byte)(91)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(679, 40);
            this.bunifuGradientPanel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ingreso de animales";
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(585, 5);
            this.btnMinimizar.Margin = new System.Windows.Forms.Padding(5);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(30, 30);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMinimizar.TabIndex = 3;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(625, 5);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 30);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnCerrar.TabIndex = 2;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // frmElipse
            // 
            this.frmElipse.ElipseRadius = 20;
            this.frmElipse.TargetControl = this;
            // 
            // txtNomComun
            // 
            this.txtNomComun.AcceptsReturn = false;
            this.txtNomComun.AcceptsTab = false;
            this.txtNomComun.AnimationSpeed = 200;
            this.txtNomComun.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNomComun.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNomComun.AutoSizeHeight = true;
            this.txtNomComun.BackColor = System.Drawing.Color.Transparent;
            this.txtNomComun.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNomComun.BackgroundImage")));
            this.txtNomComun.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtNomComun.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNomComun.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtNomComun.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtNomComun.BorderRadius = 20;
            this.txtNomComun.BorderThickness = 1;
            this.txtNomComun.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNomComun.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomComun.DefaultFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomComun.DefaultText = "";
            this.txtNomComun.FillColor = System.Drawing.Color.White;
            this.txtNomComun.HideSelection = true;
            this.txtNomComun.IconLeft = null;
            this.txtNomComun.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomComun.IconPadding = 10;
            this.txtNomComun.IconRight = null;
            this.txtNomComun.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomComun.Lines = new string[0];
            this.txtNomComun.Location = new System.Drawing.Point(20, 59);
            this.txtNomComun.MaxLength = 32767;
            this.txtNomComun.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtNomComun.Modified = false;
            this.txtNomComun.Multiline = false;
            this.txtNomComun.Name = "txtNomComun";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomComun.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtNomComun.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomComun.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomComun.OnIdleState = stateProperties8;
            this.txtNomComun.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtNomComun.PasswordChar = '\0';
            this.txtNomComun.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNomComun.PlaceholderText = "";
            this.txtNomComun.ReadOnly = false;
            this.txtNomComun.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNomComun.SelectedText = "";
            this.txtNomComun.SelectionLength = 0;
            this.txtNomComun.SelectionStart = 0;
            this.txtNomComun.ShortcutsEnabled = true;
            this.txtNomComun.Size = new System.Drawing.Size(260, 35);
            this.txtNomComun.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtNomComun.TabIndex = 7;
            this.txtNomComun.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNomComun.TextMarginBottom = 0;
            this.txtNomComun.TextMarginLeft = 3;
            this.txtNomComun.TextMarginTop = 1;
            this.txtNomComun.TextPlaceholder = "";
            this.txtNomComun.UseSystemPasswordChar = false;
            this.txtNomComun.WordWrap = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 21);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nombre común";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nombre científico";
            // 
            // txtNomCientifico
            // 
            this.txtNomCientifico.AcceptsReturn = false;
            this.txtNomCientifico.AcceptsTab = false;
            this.txtNomCientifico.AnimationSpeed = 200;
            this.txtNomCientifico.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNomCientifico.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNomCientifico.AutoSizeHeight = true;
            this.txtNomCientifico.BackColor = System.Drawing.Color.Transparent;
            this.txtNomCientifico.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNomCientifico.BackgroundImage")));
            this.txtNomCientifico.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtNomCientifico.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtNomCientifico.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtNomCientifico.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtNomCientifico.BorderRadius = 20;
            this.txtNomCientifico.BorderThickness = 1;
            this.txtNomCientifico.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNomCientifico.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomCientifico.DefaultFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomCientifico.DefaultText = "";
            this.txtNomCientifico.FillColor = System.Drawing.Color.White;
            this.txtNomCientifico.HideSelection = true;
            this.txtNomCientifico.IconLeft = null;
            this.txtNomCientifico.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomCientifico.IconPadding = 10;
            this.txtNomCientifico.IconRight = null;
            this.txtNomCientifico.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNomCientifico.Lines = new string[0];
            this.txtNomCientifico.Location = new System.Drawing.Point(382, 59);
            this.txtNomCientifico.MaxLength = 32767;
            this.txtNomCientifico.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtNomCientifico.Modified = false;
            this.txtNomCientifico.Multiline = false;
            this.txtNomCientifico.Name = "txtNomCientifico";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomCientifico.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtNomCientifico.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomCientifico.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNomCientifico.OnIdleState = stateProperties12;
            this.txtNomCientifico.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtNomCientifico.PasswordChar = '\0';
            this.txtNomCientifico.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNomCientifico.PlaceholderText = "";
            this.txtNomCientifico.ReadOnly = false;
            this.txtNomCientifico.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNomCientifico.SelectedText = "";
            this.txtNomCientifico.SelectionLength = 0;
            this.txtNomCientifico.SelectionStart = 0;
            this.txtNomCientifico.ShortcutsEnabled = true;
            this.txtNomCientifico.Size = new System.Drawing.Size(221, 35);
            this.txtNomCientifico.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtNomCientifico.TabIndex = 9;
            this.txtNomCientifico.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNomCientifico.TextMarginBottom = 0;
            this.txtNomCientifico.TextMarginLeft = 3;
            this.txtNomCientifico.TextMarginTop = 1;
            this.txtNomCientifico.TextPlaceholder = "";
            this.txtNomCientifico.UseSystemPasswordChar = false;
            this.txtNomCientifico.WordWrap = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(378, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 21);
            this.label4.TabIndex = 14;
            this.label4.Text = "Descripción del hábitat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 21);
            this.label5.TabIndex = 12;
            this.label5.Text = "Clasificación";
            // 
            // cbClasificacion
            // 
            this.cbClasificacion.BackColor = System.Drawing.Color.Transparent;
            this.cbClasificacion.BaseColor = System.Drawing.Color.White;
            this.cbClasificacion.BorderColor = System.Drawing.Color.Silver;
            this.cbClasificacion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbClasificacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClasificacion.FocusedColor = System.Drawing.Color.Empty;
            this.cbClasificacion.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.cbClasificacion.ForeColor = System.Drawing.Color.Black;
            this.cbClasificacion.FormattingEnabled = true;
            this.cbClasificacion.Location = new System.Drawing.Point(20, 142);
            this.cbClasificacion.Name = "cbClasificacion";
            this.cbClasificacion.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.cbClasificacion.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cbClasificacion.Radius = 10;
            this.cbClasificacion.Size = new System.Drawing.Size(260, 31);
            this.cbClasificacion.TabIndex = 16;
            // 
            // bunifuGroupBox1
            // 
            this.bunifuGroupBox1.BorderColor = System.Drawing.Color.LightGray;
            this.bunifuGroupBox1.BorderRadius = 20;
            this.bunifuGroupBox1.BorderThickness = 1;
            this.bunifuGroupBox1.Controls.Add(this.label6);
            this.bunifuGroupBox1.Controls.Add(this.txtID);
            this.bunifuGroupBox1.Controls.Add(this.bunifuGroupBox2);
            this.bunifuGroupBox1.Controls.Add(this.cbDescripcion);
            this.bunifuGroupBox1.Controls.Add(this.label2);
            this.bunifuGroupBox1.Controls.Add(this.txtNomComun);
            this.bunifuGroupBox1.Controls.Add(this.cbClasificacion);
            this.bunifuGroupBox1.Controls.Add(this.txtNomCientifico);
            this.bunifuGroupBox1.Controls.Add(this.label4);
            this.bunifuGroupBox1.Controls.Add(this.label3);
            this.bunifuGroupBox1.Controls.Add(this.label5);
            this.bunifuGroupBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuGroupBox1.LabelAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuGroupBox1.LabelIndent = 10;
            this.bunifuGroupBox1.LineStyle = Bunifu.UI.WinForms.BunifuGroupBox.LineStyles.Solid;
            this.bunifuGroupBox1.Location = new System.Drawing.Point(16, 57);
            this.bunifuGroupBox1.Name = "bunifuGroupBox1";
            this.bunifuGroupBox1.Size = new System.Drawing.Size(633, 292);
            this.bunifuGroupBox1.TabIndex = 17;
            this.bunifuGroupBox1.TabStop = false;
            this.bunifuGroupBox1.Text = "Datos Generales";
            // 
            // bunifuGroupBox2
            // 
            this.bunifuGroupBox2.BorderColor = System.Drawing.Color.LightGray;
            this.bunifuGroupBox2.BorderRadius = 20;
            this.bunifuGroupBox2.BorderThickness = 1;
            this.bunifuGroupBox2.Controls.Add(this.btnCargarFoto);
            this.bunifuGroupBox2.Controls.Add(this.pictureBox1);
            this.bunifuGroupBox2.Controls.Add(this.btnAgregarFoto);
            this.bunifuGroupBox2.Controls.Add(this.lbNombreFoto);
            this.bunifuGroupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuGroupBox2.LabelAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuGroupBox2.LabelIndent = 10;
            this.bunifuGroupBox2.LineStyle = Bunifu.UI.WinForms.BunifuGroupBox.LineStyles.Solid;
            this.bunifuGroupBox2.Location = new System.Drawing.Point(20, 188);
            this.bunifuGroupBox2.Name = "bunifuGroupBox2";
            this.bunifuGroupBox2.Size = new System.Drawing.Size(579, 84);
            this.bunifuGroupBox2.TabIndex = 19;
            this.bunifuGroupBox2.TabStop = false;
            this.bunifuGroupBox2.Text = "Foto";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(33, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(21, 21);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // btnAgregarFoto
            // 
            this.btnAgregarFoto.ActiveBorderThickness = 1;
            this.btnAgregarFoto.ActiveCornerRadius = 20;
            this.btnAgregarFoto.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnAgregarFoto.ActiveForecolor = System.Drawing.Color.White;
            this.btnAgregarFoto.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnAgregarFoto.BackColor = System.Drawing.SystemColors.Control;
            this.btnAgregarFoto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgregarFoto.BackgroundImage")));
            this.btnAgregarFoto.ButtonText = "Agregar Foto";
            this.btnAgregarFoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregarFoto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarFoto.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnAgregarFoto.IdleBorderThickness = 1;
            this.btnAgregarFoto.IdleCornerRadius = 20;
            this.btnAgregarFoto.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnAgregarFoto.IdleForecolor = System.Drawing.Color.White;
            this.btnAgregarFoto.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnAgregarFoto.Location = new System.Drawing.Point(376, 24);
            this.btnAgregarFoto.Margin = new System.Windows.Forms.Padding(5);
            this.btnAgregarFoto.Name = "btnAgregarFoto";
            this.btnAgregarFoto.Size = new System.Drawing.Size(164, 41);
            this.btnAgregarFoto.TabIndex = 10;
            this.btnAgregarFoto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbNombreFoto
            // 
            this.lbNombreFoto.AutoSize = true;
            this.lbNombreFoto.Location = new System.Drawing.Point(63, 37);
            this.lbNombreFoto.Name = "lbNombreFoto";
            this.lbNombreFoto.Size = new System.Drawing.Size(57, 21);
            this.lbNombreFoto.TabIndex = 0;
            this.lbNombreFoto.Text = "label6";
            // 
            // cbDescripcion
            // 
            this.cbDescripcion.BackColor = System.Drawing.Color.Transparent;
            this.cbDescripcion.BaseColor = System.Drawing.Color.White;
            this.cbDescripcion.BorderColor = System.Drawing.Color.Silver;
            this.cbDescripcion.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbDescripcion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDescripcion.FocusedColor = System.Drawing.Color.Empty;
            this.cbDescripcion.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDescripcion.ForeColor = System.Drawing.Color.Black;
            this.cbDescripcion.FormattingEnabled = true;
            this.cbDescripcion.Location = new System.Drawing.Point(382, 142);
            this.cbDescripcion.Name = "cbDescripcion";
            this.cbDescripcion.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.cbDescripcion.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cbDescripcion.Radius = 10;
            this.cbDescripcion.Size = new System.Drawing.Size(221, 32);
            this.cbDescripcion.TabIndex = 18;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // bunifuGroupBox3
            // 
            this.bunifuGroupBox3.BorderColor = System.Drawing.Color.LightGray;
            this.bunifuGroupBox3.BorderRadius = 20;
            this.bunifuGroupBox3.BorderThickness = 1;
            this.bunifuGroupBox3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuGroupBox3.LabelAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuGroupBox3.LabelIndent = 10;
            this.bunifuGroupBox3.LineStyle = Bunifu.UI.WinForms.BunifuGroupBox.LineStyles.Solid;
            this.bunifuGroupBox3.Location = new System.Drawing.Point(16, 369);
            this.bunifuGroupBox3.Name = "bunifuGroupBox3";
            this.bunifuGroupBox3.Size = new System.Drawing.Size(633, 164);
            this.bunifuGroupBox3.TabIndex = 20;
            this.bunifuGroupBox3.TabStop = false;
            this.bunifuGroupBox3.Text = "Datos Específicos";
            // 
            // btnVolverMenu
            // 
            this.btnVolverMenu.ActiveBorderThickness = 1;
            this.btnVolverMenu.ActiveCornerRadius = 20;
            this.btnVolverMenu.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnVolverMenu.ActiveForecolor = System.Drawing.Color.White;
            this.btnVolverMenu.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnVolverMenu.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolverMenu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnVolverMenu.BackgroundImage")));
            this.btnVolverMenu.ButtonText = "Volver al menú";
            this.btnVolverMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolverMenu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverMenu.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnVolverMenu.IdleBorderThickness = 1;
            this.btnVolverMenu.IdleCornerRadius = 20;
            this.btnVolverMenu.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnVolverMenu.IdleForecolor = System.Drawing.Color.White;
            this.btnVolverMenu.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnVolverMenu.Location = new System.Drawing.Point(485, 552);
            this.btnVolverMenu.Margin = new System.Windows.Forms.Padding(5);
            this.btnVolverMenu.Name = "btnVolverMenu";
            this.btnVolverMenu.Size = new System.Drawing.Size(164, 41);
            this.btnVolverMenu.TabIndex = 11;
            this.btnVolverMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnVolverMenu.Click += new System.EventHandler(this.btnVolverMenu_Click);
            // 
            // btnIngresar
            // 
            this.btnIngresar.ActiveBorderThickness = 1;
            this.btnIngresar.ActiveCornerRadius = 20;
            this.btnIngresar.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnIngresar.ActiveForecolor = System.Drawing.Color.White;
            this.btnIngresar.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnIngresar.BackColor = System.Drawing.SystemColors.Control;
            this.btnIngresar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIngresar.BackgroundImage")));
            this.btnIngresar.ButtonText = "Ingresar registro";
            this.btnIngresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIngresar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresar.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnIngresar.IdleBorderThickness = 1;
            this.btnIngresar.IdleCornerRadius = 20;
            this.btnIngresar.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnIngresar.IdleForecolor = System.Drawing.Color.White;
            this.btnIngresar.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnIngresar.Location = new System.Drawing.Point(16, 552);
            this.btnIngresar.Margin = new System.Windows.Forms.Padding(5);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(164, 41);
            this.btnIngresar.TabIndex = 21;
            this.btnIngresar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtID
            // 
            this.txtID.AcceptsReturn = false;
            this.txtID.AcceptsTab = false;
            this.txtID.AnimationSpeed = 200;
            this.txtID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtID.AutoSizeHeight = true;
            this.txtID.BackColor = System.Drawing.Color.Transparent;
            this.txtID.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtID.BackgroundImage")));
            this.txtID.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtID.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtID.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtID.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtID.BorderRadius = 20;
            this.txtID.BorderThickness = 1;
            this.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtID.DefaultFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.DefaultText = "";
            this.txtID.FillColor = System.Drawing.Color.White;
            this.txtID.HideSelection = true;
            this.txtID.IconLeft = null;
            this.txtID.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtID.IconPadding = 10;
            this.txtID.IconRight = null;
            this.txtID.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtID.Lines = new string[0];
            this.txtID.Location = new System.Drawing.Point(301, 59);
            this.txtID.MaxLength = 32767;
            this.txtID.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtID.Modified = false;
            this.txtID.Multiline = false;
            this.txtID.Name = "txtID";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtID.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtID.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtID.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtID.OnIdleState = stateProperties4;
            this.txtID.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.txtID.PasswordChar = '\0';
            this.txtID.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtID.PlaceholderText = "";
            this.txtID.ReadOnly = false;
            this.txtID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtID.SelectedText = "";
            this.txtID.SelectionLength = 0;
            this.txtID.SelectionStart = 0;
            this.txtID.ShortcutsEnabled = true;
            this.txtID.Size = new System.Drawing.Size(62, 31);
            this.txtID.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtID.TabIndex = 20;
            this.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtID.TextMarginBottom = 0;
            this.txtID.TextMarginLeft = 3;
            this.txtID.TextMarginTop = 1;
            this.txtID.TextPlaceholder = "";
            this.txtID.UseSystemPasswordChar = false;
            this.txtID.WordWrap = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(297, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 21);
            this.label6.TabIndex = 21;
            this.label6.Text = "ID";
            // 
            // btnCargarFoto
            // 
            this.btnCargarFoto.ActiveBorderThickness = 1;
            this.btnCargarFoto.ActiveCornerRadius = 20;
            this.btnCargarFoto.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnCargarFoto.ActiveForecolor = System.Drawing.Color.White;
            this.btnCargarFoto.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(170)))), ((int)(((byte)(40)))));
            this.btnCargarFoto.BackColor = System.Drawing.SystemColors.Control;
            this.btnCargarFoto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCargarFoto.BackgroundImage")));
            this.btnCargarFoto.ButtonText = "Cargar Foto";
            this.btnCargarFoto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCargarFoto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargarFoto.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnCargarFoto.IdleBorderThickness = 1;
            this.btnCargarFoto.IdleCornerRadius = 20;
            this.btnCargarFoto.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnCargarFoto.IdleForecolor = System.Drawing.Color.White;
            this.btnCargarFoto.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(156)))), ((int)(((byte)(29)))));
            this.btnCargarFoto.Location = new System.Drawing.Point(202, 24);
            this.btnCargarFoto.Margin = new System.Windows.Forms.Padding(5);
            this.btnCargarFoto.Name = "btnCargarFoto";
            this.btnCargarFoto.Size = new System.Drawing.Size(164, 41);
            this.btnCargarFoto.TabIndex = 12;
            this.btnCargarFoto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmIngreso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 607);
            this.Controls.Add(this.btnIngresar);
            this.Controls.Add(this.btnVolverMenu);
            this.Controls.Add(this.bunifuGroupBox3);
            this.Controls.Add(this.bunifuGroupBox1);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "FrmIngreso";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmIngreso";
            this.Load += new System.EventHandler(this.FrmIngreso_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            this.bunifuGroupBox1.ResumeLayout(false);
            this.bunifuGroupBox1.PerformLayout();
            this.bunifuGroupBox2.ResumeLayout(false);
            this.bunifuGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        protected Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        protected System.Windows.Forms.Label label1;
        protected System.Windows.Forms.PictureBox btnMinimizar;
        protected System.Windows.Forms.PictureBox btnCerrar;
        protected Bunifu.UI.WinForms.BunifuGroupBox bunifuGroupBox1;
        protected Bunifu.UI.WinForms.BunifuGroupBox bunifuGroupBox2;
        protected System.Windows.Forms.Label lbNombreFoto;
        protected Guna.UI.WinForms.GunaComboBox cbDescripcion;
        protected System.Windows.Forms.Label label2;
        protected Bunifu.UI.WinForms.BunifuTextBox txtNomComun;
        protected Guna.UI.WinForms.GunaComboBox cbClasificacion;
        protected Bunifu.UI.WinForms.BunifuTextBox txtNomCientifico;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.Label label5;
        protected Bunifu.Framework.UI.BunifuThinButton2 btnVolverMenu;
        protected Bunifu.Framework.UI.BunifuThinButton2 btnAgregarFoto;
        protected Bunifu.Framework.UI.BunifuThinButton2 btnIngresar;
        protected System.Windows.Forms.PictureBox pictureBox1;
        protected Bunifu.UI.WinForms.BunifuGroupBox bunifuGroupBox3;
        protected Bunifu.Framework.UI.BunifuElipse frmElipse;
        protected System.Windows.Forms.OpenFileDialog openFileDialog1;
        protected System.Windows.Forms.Label label6;
        protected Bunifu.UI.WinForms.BunifuTextBox txtID;
        protected Bunifu.Framework.UI.BunifuThinButton2 btnCargarFoto;
    }
}