﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProyectoDeCatedraPOOFinal
{
    public partial class FrmPez : ProyectoDeCatedraPOOFinal.FrmIngreso
    {
        public FrmPez()
        {
            InitializeComponent();
        }

        private void FrmPez_Load(object sender, EventArgs e)
        {
            cbTipoBranquias.Items.Clear();
            cbTipoBranquias.Items.Add("Externas");
            cbTipoBranquias.Items.Add("Internas");
        }
    }
}
